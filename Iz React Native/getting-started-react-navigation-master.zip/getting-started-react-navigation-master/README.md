Code for [intro to React Navigation tutorial](https://hackernoon.com/getting-started-with-react-navigation-the-navigation-solution-for-react-native-ea3f4bd786a4).

# Installation

- `git clone https://github.com/spencercarli/getting-started-react-navigation.git`
- `cd getting-started-react-navigation`
- `npm install`


# Running

- `react-native run-ios`
- `react-native run-android`

## Expo

You can also run this using Expo - check out [this repo](https://github.com/ricbermo/getting-started-react-navigation-expo).
